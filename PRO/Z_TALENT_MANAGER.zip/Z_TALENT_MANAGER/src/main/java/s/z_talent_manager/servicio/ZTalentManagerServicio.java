/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package s.z_talent_manager.servicio;


import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import s.z_talent_manager.dao.CandidatoDAO;
import s.z_talent_manager.dao.CandidatoImpl;
import s.z_talent_manager.dao.CurriculumDAO;
import s.z_talent_manager.dao.CurriculumIdiomaDAO;
import s.z_talent_manager.dao.CurriculumIdiomaImpl;
import s.z_talent_manager.dao.CurriculumImpl;
import s.z_talent_manager.dao.CurriculumTecnicaDAO;
import s.z_talent_manager.dao.CurriculumTecnicaImpl;
import s.z_talent_manager.dao.CurriculumTitulacionDAO;
import s.z_talent_manager.dao.CurriculumTitulacionImpl;
import s.z_talent_manager.dao.CurriculumTransversalDAO;
import s.z_talent_manager.dao.CurriculumTransversalImpl;
import s.z_talent_manager.dao.ExperienciaDAO;
import s.z_talent_manager.dao.ExperienciaImpl;
import s.z_talent_manager.modelo.Candidato;
import s.z_talent_manager.modelo.Curriculum;
import s.z_talent_manager.util.JPAUtil;
import s.z_talent_manager.util.PasswordUtils;

/**
 *
 * @author DAW1
 */
public class ZTalentManagerServicio {
    
    private CandidatoDAO candidatoDAO;
    private CurriculumDAO curriculumDAO;
    private CurriculumIdiomaDAO curriculumIdiomaDAO;
    private CurriculumTecnicaDAO curriculumTecnicaDAO;
    private CurriculumTitulacionDAO curriculumTitulacionDAO;
    private CurriculumTransversalDAO curriculumTransversalDAO;
    private ExperienciaDAO experienciaDAO;
    
    private static ZTalentManagerServicio servicio = null;
    
    public static ZTalentManagerServicio getServicio() {
        if (servicio == null) {
            servicio = new ZTalentManagerServicio();
        }
        return servicio;
    }

    private ZTalentManagerServicio() {
        candidatoDAO = new CandidatoImpl();
        curriculumDAO = new CurriculumImpl();
        curriculumIdiomaDAO = new CurriculumIdiomaImpl();
        curriculumTecnicaDAO = new CurriculumTecnicaImpl();
        curriculumTitulacionDAO = new CurriculumTitulacionImpl();
        curriculumTransversalDAO = new CurriculumTransversalImpl();
        experienciaDAO = new ExperienciaImpl();
    }
        
    
    /* CANDIDATO --Hiem */
    
   /* ===== Ver perfil desde candidato. =====
     - Candidato visualiza su perfil y curriculum. */    
    
    public Candidato getCandidato(Integer idCandidato) {
        try 
           (EntityManager em = JPAUtil.getEntityManager()) {
        return candidatoDAO.getCandidato(em, idCandidato);
    }
}
    /* ===== Ver curriculum del candidato. =====
   - Candidato visualiza el contenido de su curriculum desde las pestañas del perfil. */    
   public Curriculum getCurriculum(Integer idCurriculum) {
        try 
          (EntityManager em = JPAUtil.getEntityManager()) {
        return curriculumDAO.getCurriculum(em, idCurriculum);
    }
}
 
   /* ===== Cambio de contraseña desde candidato. =====
     - Lanza excepción si la contraseña actual introducida por el candidato es incorrecta.
     - Lanza excepción si la nueva contraseña es igual a la anterior. */
   
   public void cambiarContrasena(Integer idCandidato, String contrasenaActual, String contrasenaNueva) {
        try 
            (EntityManager em = JPAUtil.getEntityManager()) {
             EntityTransaction tx = em.getTransaction();
        try {
            Candidato c = candidatoDAO.getCandidato(em, idCandidato);

            if (!PasswordUtils.checkPw(contrasenaActual, c.getContraseña())) {
                throw new RuntimeException(
                        "La contraseña actual no es correcta");
            }
            if (PasswordUtils.checkPw(contrasenaNueva, c.getContraseña())) {
                throw new RuntimeException(
                        "La nueva contraseña no puede ser igual a la anterior");
            }

            c.setContraseña(PasswordUtils.getHash(contrasenaNueva));
            tx.begin();
            candidatoDAO.modificarCandidato(em, c);
            tx.commit();
        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback();
            throw new RuntimeException(ex.getMessage());
        }
    }
}
   
   /* ===== Editar Datos Personales del Candidato =====
     - Candidato modifica los campos: municipio, provincia, telefono, fechaNacimiento,
        genero desde su perfil. */   
   public void editarDatosPersonales(Candidato candidato) {
        try 
            (EntityManager em = JPAUtil.getEntityManager()) {
             EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            candidatoDAO.modificarCandidato(em, candidato);
            tx.commit();
        } catch (Exception ex) {
            if (tx.isActive()) tx.rollback();
            throw new RuntimeException(ex.getMessage());
        }
    }
}
    
    
    /// Curriculum --Carlos ///
    
    /// CurriculumIdioma -- Diego ///
    
    /// CurriculumTecnica -- Unax ///
    
    /// CurriculumTitulacion --Carlos ///
    
    /// CurriculumTransversal --Diego ///
    
    /// Experiencia --Unax ///
    
    
            }

